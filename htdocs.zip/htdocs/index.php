<?php
header("location:Views/MenuPrincipal.php");
?>