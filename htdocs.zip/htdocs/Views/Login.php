<?php
include_once '../Controller/LoginController.php';
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Iniciar Sesion | Registrase</title>
    <style>
        /* Estilos Generales */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: #f5f5f5;
        }

        .cont {
            position: relative;
            width: 900px;
            height: 600px;
            background: #fff;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            border-radius: 15px;
            overflow: hidden;
            display: flex;
        }

        .form-container {
            width: 50%;
            background: #fff;
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .form-content {
            width: 100%;
            max-width: 350px;
        }

        h2 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .input-container {
            position: relative;
            margin-bottom: 20px;
        }

        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            outline: none;
            font-size: 16px;
            color: #333;
        }

        input:focus {
            border-color: #6a82fb;
        }

        .checkbox-container {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        button {
            width: 100%;
            padding: 10px;
            background: linear-gradient(90deg, #6a82fb, #fc5c7d);
            border: none;
            color: #fff;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background: linear-gradient(90deg, #fc5c7d, #6a82fb);
        }

        p {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
        }

        p a {
            color: #6a82fb;
            text-decoration: none;
        }

        .info-container {
            width: 50%;
            background: linear-gradient(135deg, #6a82fb, #fc5c7d);
            color: #fff;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .info-container h2 {
            font-size: 28px;
            margin-bottom: 20px;
        }

        .info-container p {
            font-size: 16px;
            text-align: center;
            line-height: 1.5;
        }

        .img__btn {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
            cursor: pointer;
        }

        .img__btn span {
            font-size: 16px;
            padding: 10px 20px;
            border-radius: 5px;
            background: #fff;
            color: #6a82fb;
            transition: 0.3s;
        }

        .img__btn span:hover {
            background: #6a82fb;
            color: #fff;
        }

        .cont.s--signup .sign-in {
            display: none;
        }

        .cont.s--signup .sign-up {
            display: block;
        }

        .sign-up {
            display: none;
        }
    </style>
</head>

<body>
    <br>
    <br>
    <div class="cont">
        <div class="form-container sign-in">
            <div class="form-content">
                <h2>Bienvenido</h2>
                <?php
                if (isset($_POST["msj"])) {
                    echo '<div class="alert alert-info TextoCentrado">' . $_POST["msj"] . '</div>';
                }
                ?>
                <form action="" method="post">
                    <label class="input-container">
                        <span>Correo</span>
                        <input type="email" id="txtEmail" name="txtEmail" />
                    </label>
                    <label class="input-container">
                        <span>Contraseña</span>
                        <input type="password" id="txtPassword" name="txtPassword" />
                    </label>
                    <button type="submit" class="submit" id="btnIniciarSesion" name="btnIniciarSesion">Iniciar sesión</button>
                </form>
            </div>
        </div>
        <div class="info-container sub-cont">
            <div class="img">
                <div class="img__text m--up">
                    <h3>No tiene cuenta? Por favor regístrese!</h3>
                </div>
                <div class="img__text m--in">
                    <h3>Si ya tiene cuenta, Inicie sesión.</h3>
                </div>
                <div class="img__btn">
                    <span class="m--up">Registrarse</span>
                    <span class="m--in">Iniciar Sesión</span>
                </div>
            </div>
        </div>
        <div class="form-container sign-up">
            <div class="form-content">
                <h2>Crear Cuenta</h2>
                <?php
                if (isset($_POST["msj"])) {
                    echo '<div class="alert alert-info TextoCentrado">' . $_POST["msj"] . '</div>';
                }
                ?>
                <form action="" method="post">
                    <label class="input-container">
                        <span>Identificación</span>
                        <input type="text" id="txtIdentificacion" name="txtIdentificacion" onkeyup="BuscarCedula()" />
                    </label>
                    <label class="input-container">
                        <span>Nombre</span>
                        <input type="text" id="txtNombre" name="txtNombre"readonly />
                    </label>
                    <label class="input-container">
                        <span>Correo</span>
                        <input type="email" id="txtEmailNew" name="txtEmailNew" />
                    </label>
                    <label class="input-container">
                        <span>Contraseña</span>
                        <input type="password" id="txtPasswordNew" name="txtPasswordNew" />
                    </label>
                    <button type="submit" class="submit" id="btnRegistrarUsuario" name="btnRegistrarUsuario">Registrarse</button>
                </form>
            </div>
        </div>
    </div>
    <script src="../js/jquery.js"></script>
    <script>
        document.querySelector('.img__btn').addEventListener('click', function() {
            document.querySelector('.cont').classList.toggle('s--signup');
        });

        function BuscarCedula() {
            let CEDULA = $("#txtIdentificacion").val();
            if (CEDULA.trim().length >= 8) {
                $.ajax({
                    url: "https://apis.gometa.org/cedulas/" + CEDULA,
                    type: "GET",
                    dataType: 'json',
                    success: function(res) {
                        $("#txtNombre").val(res.results[0]?.firstname + " " + res.results[0]?.lastname);
                    },
                    error: function(res) {
                        alert("Error" + res);
                    }
                });
            }
        };
    </script>
</body>

</html>
